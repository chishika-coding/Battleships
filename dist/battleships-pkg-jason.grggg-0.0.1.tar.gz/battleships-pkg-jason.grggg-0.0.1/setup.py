import setuptools

with open('README.md', 'r') as fh:
    long_description = fh.read()

packages=setuptools.find_packages()
print(packages)

setuptools.setup(
    name='battleships-pkg-jason.grggg',
    version='0.0.1',
    author ='jgrg',
    author_email="jg988@exeter.ac.uk",
    description='A program to play the game Battleships against a computer',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bakapaka/Battleships",
    packages=setuptools.find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.11',

    
)
